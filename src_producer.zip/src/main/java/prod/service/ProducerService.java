package prod.service;

import java.util.List;
import prod.bean.User;


public interface ProducerService {
	
    public User getUserByName(String name);

    public List<User> getUsersByAge(int age);

    /**
     * 
     * @param id
     * @return
     */
    public User getUserByID( long id);

    /**
     * 
     * @return
     */
    public List<User> getUserList();
}
