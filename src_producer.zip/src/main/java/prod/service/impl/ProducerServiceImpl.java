package prod.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;


import prod.bean.User;
import prod.service.ProducerService;


@Service("producerService")
public class ProducerServiceImpl implements ProducerService {
	
    public User getUserByName(String name){
    	
    	User user = new User();
    	
    	if( "aws".equals(name)){
    		user.setId(18134496);
        	user.setUserName("亚马逊");
        	user.setAge(35);
        	user.setSex(0);
        	user.setEmail("aws@aws.com");
        	user.setUserNameEN("abner");
    	}
    	else if( "jlj".equals(name)){
    		user.setId(18134496);
        	user.setUserName("蒋立杰");
        	user.setAge(35);
        	user.setSex(0);
        	user.setEmail("jianglj@suningbank.com");
        	user.setUserNameEN("jlj");
    	}
    	else {
    		user.setId(0);
        	user.setUserName("未知");
        	user.setAge(35);
        	user.setSex(0);
        	user.setEmail("未知");
        	user.setUserNameEN("未知");
    	}
    	return user;
    }

    public List<User> getUsersByAge(int age){
    	List<User> userList = new ArrayList<User>();
    	
    	User user1 = new User();
    	if( 35 == age ){
    		user1.setId(18134496);
        	user1.setUserName("aws");
        	user1.setAge(35);
        	user1.setSex(0);
        	user1.setEmail("aws@aws.com");
        	user1.setUserNameEN("aws");
        	
        	userList.add(user1);
    	}
    	
    	User user2 = new User();
        if( 35 == age ){
        	
        	user2.setId(18134496);
        	user2.setUserName("蒋立杰");
        	user2.setAge(35);
        	user2.setSex(0);
        	user2.setEmail("jianglj@suningbank.com");
        	user2.setUserNameEN("jlj");
        
        	userList.add(user2);
    	}
    	
    	return userList;
    }

    /**
     * 
     * @param id
     * @return
     */
    public User getUserByID( long id){
    	
    	User user = new User();
    	
    	if( "18134496".equals(id)){
    		user.setId(18134496);
        	user.setUserName("aws");
        	user.setAge(35);
        	user.setSex(0);
        	user.setEmail("aws@aws.com");
        	user.setUserNameEN("aws");
    	}
    	if( "17111352".equals(id)){
    		user.setId(18134496);
        	user.setUserName("蒋立杰");
        	user.setAge(35);
        	user.setSex(0);
        	user.setEmail("jianglj@suningbank.com");
        	user.setUserNameEN("jlj");
    	}

    	return user;
    	
    }

    /**
     * 
     * @return
     */
    public List<User> getUserList(){
    	User user1 = new User();
    	user1.setId(18134496);
    	user1.setUserName("aws");
    	user1.setAge(35);
    	user1.setSex(0);
    	user1.setEmail("aws@aws.com");
    	user1.setUserNameEN("aws");
    	
    	User user2 = new User();
    	user2.setId(18134496);
    	user2.setUserName("蒋立杰");
    	user2.setAge(35);
    	user2.setSex(0);
    	user2.setEmail("jianglj@suningbank.com");
    	user2.setUserNameEN("jlj");
    	
    	List<User> userList = new ArrayList<User>();
    	userList.add(user1);
    	userList.add(user2);
    	
    	return userList;
    }

}
