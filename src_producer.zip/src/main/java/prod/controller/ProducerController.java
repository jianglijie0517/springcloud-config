package prod.controller;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSON;

import prod.bean.User;
import prod.service.ProducerService;

@RestController
public class ProducerController {
	
	@Autowired
	ProducerService producerService;
	
	@GetMapping(value="/user/name/{name}")
    public String  getUserByName(@PathVariable("name") String name){
		User user = producerService.getUserByName(name);
		return JSON.toJSONString(user);
	}

	@GetMapping(value="/user/age/{age}")
    public String getUsersByAge(@PathVariable("age") int age){
		List<User> listUser = producerService.getUsersByAge(age);
		return JSON.toJSONString(listUser);
	}

    
    @GetMapping(value="/user/{id}")
    public String getUserByID(@PathVariable("id") long id){
    	User user = producerService.getUserByID(id);
		return JSON.toJSONString(user);
    }

    @RequestMapping(value="/user/list")
    public String getUserList(){
    	List<User> listUser = producerService.getUserList();
		return JSON.toJSONString(listUser);
    }
    
    @Value("${server.port}")
    private String port;
    
    @Value("${eureka.instance.hostname}")
    private String hostIP;
    
    @GetMapping(value = "/thread")
    public String getHostAddress(){
    	InetAddress address = null;
    	
    	try {
			address = InetAddress.getLocalHost();
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    	return "当前调用服务的Ip地址为： " + hostIP + "-" + address.getHostAddress() + ":" + port;
    }
	

}
