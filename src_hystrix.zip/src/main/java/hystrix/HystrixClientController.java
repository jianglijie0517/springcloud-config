package hystrix;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import java.util.Random;


@RestController
public class HystrixClientController {

    @Autowired
    RestTemplate restTemplate;



    @GetMapping(value = "/config")
    @HystrixCommand(fallbackMethod="error")
    public String getConfigNormal(@RequestParam(value="time", defaultValue = "0") int time){
        System.out.println("time: " + time);
        try {
            Thread.sleep(time * 1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return "Hello AWS ";
    }

    public String error( int time){
        return "服务已经降级";
    }
}
