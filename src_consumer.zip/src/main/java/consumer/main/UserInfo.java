package consumer.main;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;


@FeignClient(value = "user-service")
public interface UserInfo {
	
	@RequestMapping(value="/user/name/{name}")
    public String getUserByName(@PathVariable("name") String name);

	@GetMapping(value="/user/age/{age}")
    public String getUsersByAge(@PathVariable("age") int age);

    
    @RequestMapping(value="/user/{id}")
    public String getUserByID(@PathVariable("id") long id);

    @RequestMapping(value="/user/list")
    public String getUserList();
    
    @RequestMapping(value="/thread")
    public String getThread();
	

}
