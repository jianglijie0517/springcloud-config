package consumer.main;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import com.alibaba.fastjson.JSON;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

@RestController
public class ConsumerController {

	@Autowired
	private UserInfo userInfo;
	
	@GetMapping(value="/user/name/{name}")
	@HystrixCommand(fallbackMethod="error")
    public String  getUserByName(@PathVariable("name") String name){
		return this.userInfo.getUserByName(name);

	}

	@GetMapping(value="/user/age/{age}")
    public String getUsersByAge(@PathVariable("age") int age){
		return this.userInfo.getUsersByAge(age);

	}

    
    @GetMapping(value="/user/{id}")
    public String getUserByID(@PathVariable("id") long id){
    	return this.userInfo.getUserByID(id);

    }
    
	@HystrixCommand(fallbackMethod="error")
    @GetMapping(value="/user/list")
    public String getUserList(){
    	return this.userInfo.getUserList();

    }
	
	@GetMapping(value="/thread")
	public String getThread(){
		return this.userInfo.getThread();
	}
	
    
    public String error(String name){
    	return "访问超时，服务已经降级";
    }
    
    public String error(){
    	return "访问已经超时，服务已经降级";
    }
}
