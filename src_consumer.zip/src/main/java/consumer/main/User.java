package consumer.main;

public class User {
	
	private int id;
	
	private String userName;
	
	private String userNameEN;
	
	private int age;
	
	private int sex;
	
	
	private String email;
	
	


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getUserName() {
		return userName;
	}


	public void setUserName(String userName) {
		this.userName = userName;
	}


	public String getUserNameEN() {
		return userNameEN;
	}


	public void setUserNameEN(String userNameEN) {
		this.userNameEN = userNameEN;
	}


	public int getAge() {
		return age;
	}


	public void setAge(int age) {
		this.age = age;
	}


	public int getSex() {
		return sex;
	}


	public void setSex(int sex) {
		this.sex = sex;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}
	
	

}
